<?php $__env->startSection('content'); ?>
<?php $active=true;  ?>
    <div class="justify-content-center">
            <home-map :products="<?php echo e($profiles); ?>" :categories="<?php echo e($categories); ?>"></home-map>
    </div>
<div class=" category-container ">
    <div class="row container ">
    <div class="row">

    </div>
</div>

        <footer-vue>

        </footer-vue>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\bitches\resources\views/welcome.blade.php ENDPATH**/ ?>

<!DOCTYPE HTML><html lang="es-CO">

    <head>
    <meta charset="UTF-8" />
    <link rel="profile" href="https://gmpg.org/xfn/11" />
    <title>FindHer</title>
    <link rel='dns-prefetch' href='//s.w.org' />


    <!-- Headway SEO Juice -->
    <meta name="description" content="FindHer" />
            <script type="text/javascript">
                window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/escortsbogota.com.co\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.3.2"}};
                !function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
            </script>


    <!-- Stylesheets -->
    <style type="text/css">
    img.wp-smiley,
    img.emoji {
        display: inline !important;
        border: none !important;
        box-shadow: none !important;
        height: 1em !important;
        width: 1em !important;
        margin: 0 .07em !important;
        vertical-align: -0.1em !important;
        background: none !important;
        padding: 0 !important;
    }
    </style>
        <link rel='stylesheet' id='headway-general-https-css'  href='https://escortsbogota.com.co/wp-content/uploads/headway/cache/general-https-322dbf4.css?ver=5.3.2' type='text/css' media='all' />
    <link rel='stylesheet' id='headway-layout-index-https-css'  href='https://escortsbogota.com.co/wp-content/uploads/headway/cache/layout-index-https-6a0a14f.css?ver=5.3.2' type='text/css' media='all' />
    <link rel='stylesheet' id='headway-responsive-grid-https-css'  href='https://escortsbogota.com.co/wp-content/uploads/headway/cache/responsive-grid-https-d2119e4.css?ver=5.3.2' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-block-library-css'  href='https://escortsbogota.com.co/wp-includes/css/dist/block-library/style.min.css?ver=5.3.2' type='text/css' media='all' />


    <!-- Scripts -->
   
    <script type='text/javascript' src='https://escortsbogota.com.co/wp-content/plugins/visitors-traffic-real-time-statistics/js/front.js?ver=5.3.2'></script>
    <script type='text/javascript' src='https://escortsbogota.com.co/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'></script>
    <script type='text/javascript' src='https://escortsbogota.com.co/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript' src='https://escortsbogota.com.co/wp-content/themes/headway/library/media/js/jquery.fitvids.js?ver=5.3.2'></script>
    <script type='text/javascript' src='https://escortsbogota.com.co/wp-content/uploads/headway/cache/responsive-grid-js-https-e6e6939.js?ver=5.3.2'></script>

    <!--[if lt IE 9]>
    <script src="https://escortsbogota.com.co/wp-content/themes/headway/library/media/js/html5shiv.js"></script>
    <![endif]-->

    <!--[if lt IE 8]>
    <script src="https://escortsbogota.com.co/wp-content/themes/headway/library/media/js/ie8.js"></script>
    <![endif]-->



    <!-- Extras -->
    <link rel="alternate" type="application/rss+xml" href="https://escortsbogota.com.co/feed/" title="Prepagos Bogota | Escorts Bogota: Acompañantes Hermosas" />
    <link rel="pingback" href="https://escortsbogota.com.co/xmlrpc.php" />
        <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
    <link rel="alternate" type="application/rss+xml" title="Prepagos Bogota | Escorts Bogota: Acompañantes Hermosas &raquo; Feed" href="https://escortsbogota.com.co/feed/" />
    <link rel="alternate" type="application/rss+xml" title="Prepagos Bogota | Escorts Bogota: Acompañantes Hermosas &raquo; RSS de los comentarios" href="https://escortsbogota.com.co/comments/feed/" />
    <link rel='https://api.w.org/' href='https://escortsbogota.com.co/wp-json/' />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://escortsbogota.com.co/xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://escortsbogota.com.co/wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 5.3.2" />
    <link rel="apple-touch-icon" sizes="180x180" href="/wp-content/uploads/fbrfg/apple-touch-icon.png?v=zXbQnxdrP5">
    <link rel="icon" type="image/png" sizes="32x32" href="/wp-content/uploads/fbrfg/favicon-32x32.png?v=zXbQnxdrP5">
    <link rel="icon" type="image/png" sizes="16x16" href="/wp-content/uploads/fbrfg/favicon-16x16.png?v=zXbQnxdrP5">
    <link rel="manifest" href="/wp-content/uploads/fbrfg/site.webmanifest?v=zXbQnxdrP5">
    <link rel="mask-icon" href="/wp-content/uploads/fbrfg/safari-pinned-tab.svg?v=zXbQnxdrP5" color="#5bbad5">
    <link rel="shortcut icon" href="/wp-content/uploads/fbrfg/favicon.ico?v=zXbQnxdrP5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="/wp-content/uploads/fbrfg/browserconfig.xml?v=zXbQnxdrP5">
    <meta name="theme-color" content="#ffffff">
    </head><!-- End <head> -->

    <body data-rsssl=1 class="home blog custom responsive-grid-enabled responsive-grid-active layout-index layout-using-index" itemscope itemtype="http://schema.org/WebPage">


    <div id="whitewrap">


    <div id="wrapper-w2o558307fecd158" class="wrapper wrapper-fixed wrapper-fixed-grid grid-fluid-24-25-21 responsive-grid wrapper-last" data-alias="">

    <div class="grid-container clearfix">

    <section class="row row-1">

    <section class="column column-1 grid-left-0 grid-width-24">
    <div id="block-bch558315243258a" class="block block-type-custom-code block-fluid-height" data-alias="">
    <div class="block-content">


              <font>EXCLUSIVAS ESCORTS Y PREPAGOS EN BOGOTA <br><font> SOMOS TU AGENCIA DE CONFIANZA  </font>


    </div><!-- .block-content -->

    </div><!-- #block-bch558315243258a -->

    </section><!-- .column -->

    </section><!-- .row -->


    <section class="row row-2">

    <section class="column column-1 grid-left-0 grid-width-8">
    <figure id="block-beq5583146c0b933" class="block block-type-image block-fixed-height" data-alias="" itemscope="" itemtype="http://schema.org/ImageObject">
    <div class="block-content">
    <img src="https://escortsbogota.com.co/wp-content/uploads/2015/06/modelo-index3-347x605.jpx" alt="" title="Escorts Bogota" itemprop="contentURL"/>
    </div><!-- .block-content -->

    </figure><!-- #block-beq5583146c0b933 -->

    </section><!-- .column -->

    <section class="column column-2 grid-left-0 grid-width-16">
    <div id="block-bby55830dd51f46b" class="block block-type-content block-fluid-height" data-alias="">
    <div class="block-content">
    <div class="loop"><article id="post-6" class="post-6 post type-post status-publish format-standard hentry category-uncategorized author-yosoy " itemscope itemtype="http://schema.org/Article"><header><h2 class="entry-title" itemprop="headline"><a href="https://escortsbogota.com.co/6/" title="" rel="bookmark"></a></h2></header><div class="entry-content" itemprop="text"><div align="center"><a href="https://escortsbogota.com.co/wp-content/uploads/2015/12/Bandera-de-Colombia.jpg"><img class="alignnone size-full wp-image-46" src="https://escortsbogota.com.co/wp-content/uploads/2015/12/Bandera-de-Colombia.jpg" alt="Bandera de Colombia" width="38" height="23"></a></div>
    <div align="center"><b><span style="color: #ff15d0;">SITIO DE ACOMPAÑANTES ES EXCLUSIVAMENTE PARA ADULTOS.<br />
    SI ES MENOR DE EDAD POR<br />
    FAVOR NO INGRESE</span></b></div>
    <h3 align="center"><b><span style="color: #eeeeee; font-size: 400%;"><a href="/welcome">INGRESAR AQUÍ</a></span></b></h3>
    <div align="center"><a href="https://escortsbogota.com.co/wp-content/uploads/2015/12/Bandera-de-Estados-Unidos.jpg"><img class="alignnone size-full wp-image-47" src="https://escortsbogota.com.co/wp-content/uploads/2015/12/Bandera-de-Estados-Unidos.jpg" alt="Bandera de Estados Unidos" width="38" height="23"></a></div>
    <div align="center"><b><span style="color: #ff15d0;">THIS ESCORT WEBSITE IS EXCLUSIVELY<br />
    FOR ADULTS IF YOU ARE UNDER AGE PLEASE DO NOT ENTER</span></b></div>
    <h3 align="center"><b><span style="color: #eeeeee; font-size: 400%;"><a href="/welcome">ENTER HERE</a></span></b></h3>
    </div><!-- .entry-content --></article><!-- #post-6 --></div>
    </div><!-- .block-content -->

    </div><!-- #block-bby55830dd51f46b -->

    </section><!-- .column -->

    </section><!-- .row -->







    <section class="row row-5">

    <section class="column column-1 grid-left-0 grid-width-24">
    <footer id="block-bea558311f5a8b46" class="block block-type-footer block-fluid-height" data-alias="" itemscope="" itemtype="http://schema.org/WPFooter">
    <div class="block-content">

    <div class="footer-container">

    <div class="footer">
    <p class="copyright footer-copyright"> Copyright © 2019 findHer.com.co </p><p class="footer-responsive-grid-link-container footer-responsive-grid-link-disable-container"><a href="https://escortsbogota.com.co/?full-site=true" rel="nofollow" class="footer-responsive-grid-link footer-responsive-grid-disable footer-link">View Full Site</a></p>
    </div><!-- .footer -->
    </div><!-- .footer-container -->
    </div><!-- .block-content -->

    </footer><!-- #block-bea558311f5a8b46 -->

    </section><!-- .column -->

    </section><!-- .row -->


    </div><!-- .grid-container -->

    </div><!-- .wrapper -->





    </div><!-- #whitewrap -->



    </body>
<?php /**PATH C:\xampp2\htdocs\bitches\resources\views/prehome.blade.php ENDPATH**/ ?>
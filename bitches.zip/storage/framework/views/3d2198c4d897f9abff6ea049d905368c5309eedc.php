<?php $__env->startSection('content'); ?>
<new-product-form :categories="<?php echo e(json_encode($categories)); ?>"></new-product-form>


<footer-vue></footer-vue>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\bitches\resources\views/home.blade.php ENDPATH**/ ?>
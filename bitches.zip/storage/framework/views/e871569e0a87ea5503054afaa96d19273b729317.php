<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="row">


            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <div class="card ">
                        <div class="card-header"><?php echo e($category->title); ?></div>
                        <div class="card-body">
                            <img src="images/<?php echo e($category->image); ?>" class="rounded mx-auto d-block"alt="<?php echo e($category->title); ?>">
                            <?php echo e($category->description); ?>

                            <call-to-action :number="<?php echo e(32); ?>"><img src="images/<?php echo e($category->icon); ?>" width="32" alt="<?php echo e($category->title); ?>"></call-to-action>

                        </div>
                                       </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\diogenes\resources\views/categories.blade.php ENDPATH**/ ?>
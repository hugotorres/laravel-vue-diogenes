<?php $__env->startSection('content'); ?>
<?php $active=true;  ?>
    <div class="justify-content-center">
            <home-map :products="<?php echo e($products); ?>" :categories="<?php echo e($categories); ?>"></home-map>
    </div>
<div class=" category-container hidden">
    <div class="row container ">
    <div class="row">
    <div class="  col-sm-12 padding-categories"><h3>Categorias</h3></div>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <div class="card ">
                        <div class="card-header"><?php echo e($category->title); ?></div>
                        <div class="card-body">
                            <img src="images/<?php echo e($category->image); ?>" class="rounded mx-auto d-block"alt="<?php echo e($category->title); ?>">
                            <?php echo e($category->description); ?>

                            <call-to-action :number="<?php echo e(32); ?>"><img src="images/<?php echo e($category->icon); ?>" width="32" alt="<?php echo e($category->title); ?>"></call-to-action>

                        </div>
                                       </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </div>
    </div>
</div>

        <footer-vue></footer-vue>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\diogenes\resources\views/welcome.blade.php ENDPATH**/ ?>
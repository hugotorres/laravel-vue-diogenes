<?php $__env->startSection('content'); ?>
<new-product-form :categories="<?php echo e(json_encode($categories)); ?>"></new-product-form>
<?php $products=[];?>
                      <?php if(isset($products)): ?>
                        <div class="col-sm-12" id="products">
                            <div class="panel panel-default">

                                <div class="panel-body">
                                    <div class="table-responsive-sm">
                                    <div id="confirmation-alert"></div>
                                    <table class="table table-hover table-sm"  id="result-table">
                                        <thead>
                                            <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">title</th>
                                            <th scope="col">date</th>
                                            <th scope="col">description</th>
                                            </tr>
                                        </thead>
                                        <?php  foreach ($products as $key=>$product) {?>
                                            <tr>
                                            <td><?php echo $key+1 ?></td>
                                            <td><?php echo $product['text'] ?></td>
                                            <td><?php echo $product['created_at'] ?></td>
                                            <td><?php echo $product['description'] ?></td>
                                            <td><a onclick="deleteItem(<?php echo e($product['id']); ?>)">Eliminar</a></td>
                                            </tr>
                                        <?php  } ?>

                                        </tbody>
                                    </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <?php endif; ?>
                      <footer-vue></footer-vue>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\diogenes\resources\views/home.blade.php ENDPATH**/ ?>
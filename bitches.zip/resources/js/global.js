
(function ($) {
    'use strict';
   console.log('loaded')


})(jQuery);

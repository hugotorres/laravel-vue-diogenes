<template>
  <div>
    <div
      class="side-panel"
      v-if="producto"
      v-bind:class="{ active: activeDetail , inactive: !activeDetail }"
    >
      <!--     <div class="toggle-panel" v-bind:class="{ active: isActive }" v-on:click="toggle">
      <i class="fa fa-chevron-left"></i>
      <i class="fa fa-chevron-right"></i>
      </div>-->
      <div class="side-content">
        <div class="card-header d-flex justify-content-between">
          {{producto.text}}
          <button
            type="button"
            class="close"
            aria-label="Close"
            v-on:click="toggle"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="card-body">
          <div class>
            <!--   -->
            <ul class="nav nav-tabs" id="myTab" role="tablist">
              <li class="nav-item">
                <a
                  class="nav-link active"
                  id="home-tab"
                  data-toggle="tab"
                  href="#home"
                  role="tab"
                  aria-controls="home"
                  aria-selected="true"
                >Perfil</a>
              </li>
              <li class="nav-item">
                <a
                  class="nav-link"
                  id="profile-tab"
                  data-toggle="tab"
                  href="#profile"
                  role="tab"
                  aria-controls="profile"
                  aria-selected="false"
                >Fotos</a>
              </li>
              <li class="nav-item">
                <a
                  class="nav-link"
                  id="contact-tab"
                  data-toggle="tab"
                  href="#contact"
                  role="tab"
                  aria-controls="contact"
                  aria-selected="false"
                >Contacto</a>
              </li>
            </ul>
            <div class="tab-content" id="myTabContent">
              <div
                class="tab-pane fade show active"
                id="home"
                role="tabpanel"
                aria-labelledby="home-tab"
              >
                <div class="product-description">{{producto.description}}</div>

                <div class="category">{{producto.category}}</div>
                <div class="gender">{{producto.gender}}</div>
                <div class="since">{{producto.created_at}}</div>
                <div class="updated">{{producto.updated_at}}</div>
                <div class="rating">{{producto.rating}}</div>
                {{producto.image}}
              </div>
              <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <div id="carouselExampleInterval" class="carousel slide" data-ride="carousel">
                  <div class="carousel-inner">
                    <div
                      class="carousel-item"
                      data-interval="10000"
                      v-for="(image,idx) in producto.image"
                      v-bind:key="idx"
                      :class="{ active: idx==0 || idx==null }"
                    >
                      <img v-bind:src="'/uploads/profile/' + image" class="d-block w-80 img-thumbnail" alt="..." />
                    </div>
                  </div>
                  <a
                    class="carousel-control-prev"
                    href="#carouselExampleInterval"
                    role="button"
                    data-slide="prev"
                  >
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a
                    class="carousel-control-next"
                    href="#carouselExampleInterval"
                    role="button"
                    data-slide="next"
                  >
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
              </div>
              <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="phone_number">{{producto.phone_number}}</div>
                <div class="whatsapp">{{producto.whatsapp}}</div>

                <div class="url">{{producto.url}}</div>
                <div class="url_instagram">{{producto.url_instagram}}</div>
              </div>
            </div>

            <!--  -->
          </div>
        </div>
      </div>
    </div>

    <div class="default-content" v-bind:class="{ active: !activeDetail, inactive: activeDetail }">
        <div class="col-sm-8"></div>
        <h3>Find/Her</h3>
        <p>Encuentra las mas bellas bitches en tu area</p>
        <div class="bitch-default">
            <img src class="rounded img" />
            <h4>Bitch name</h4>
            <div class="rating">5</div>
            <div class="short-description">description description description</div>
        </div>
        </div>
    </div>
  </div>
</template>
<style scoped lang="scss">
.inactive {
  display: none;
}
.active {
  display: block !important;
}
.side-panel {
  max-width: 100%;
  height: 100%;
  opacity: 1;
}
.product-image {
  border-radius: 50%;
  height: 120px;
  text-align: center;
  background: #e3e3e3;
}
.product-description {
  max-height: 200px;
  padding: 20px;
  overflow: auto;
  background: #e7e7e72e;
}
.toggle-panel.active {
  box-shadow: #c1b8b8 4px 5px 4px 1px;
  z-index: 2;
}
.toggle-panel {
  position: absolute;
  right: 0px;
  z-index: 1000;
  background: rgb(255, 1, 1);
  padding: 10px;
  transition: all 1s ease-in;
}
.side-panel.active {
  display: block;
  z-index: 10;
  opacity: 1;
}
.default-content {
  padding: 20px;
  .inactive {
    display: none;
  }
}
</style>

<script>
export default {
  name: "DetailsPanel",
  mounted() {
    this.activeDetail = this.isActive;
    this.detalles = this.producto;
  },
  updated() {
    this.activeDetail = this.isActive;
  },
  ready() {
    console.log("ready");
  },
  data() {
    return {
      images: [],
      detalles: {},
      activeDetail: null
    };
  },
  methods: {
    toggle: function(event) {
      this.activeDetail = !this.activeDetail;
      this.isActive = !this.isActive;
    }
  },

  props: {
    isActive: {
      required: true,
      type: Boolean,
      default: false
    },
    producto: {
      required: true,
      type: Object,
      default: null
    }
  }
};
</script>

/* TODO

revisa rel bug por el cual desaparece
 la variable idx que pone como active uno de  las imagenes del carousel */
